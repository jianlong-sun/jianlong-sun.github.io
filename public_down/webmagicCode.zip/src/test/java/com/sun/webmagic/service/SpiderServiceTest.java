package com.sun.webmagic.service;

import com.sun.webmagic.WebmagicApplication;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @ClassName: SpiderServiceTest
 * @Author: sunji
 * @CreateTime: 2020/12/3 14:35
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = WebmagicApplication.class)
class SpiderServiceTest {
    @Autowired
    private SpiderService spiderService;
    @Test
    void run() {
        spiderService.run();
    }
}