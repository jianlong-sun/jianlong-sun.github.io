package com.sun.webmagic.entity;

import us.codecraft.webmagic.model.annotation.*;

import javax.persistence.*;

/**
 * 盗墓笔记Spider
 *
 * @ClassName: DaoMuBiJiSpider
 * @Author: sunji
 * @CreateTime: 2020/12/3 10:08
 */
@TargetUrl("http://seputu.com/biji(\\d+)/*")
@HelpUrl("http://seputu.com/biji(\\d+)/")
@Table
@Entity
public class DaoMuBiJiSpiderNoList  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ExtractBy("/html/body/div/div[5]/h1/text()")
    private String title;
    @ExtractBy("/html/body/div/div[5]/div[1]/a/text()")
    private String origin;
    @ExtractBy("/html/body/div/div[5]/div[1]/text()")
    private String date;

    @Formatter(value = "",subClazz = Integer.class)
    @ExtractByUrl(value = "(\\d+).html",notNull = true)
    private Integer indexValue;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getIndexValue() {
        return indexValue;
    }

    public void setIndexValue(Integer indexValue) {
        this.indexValue = indexValue;
    }

    @Override
    public String toString() {
        return "DaoMuBiJiSpiderNoList{" +
                "title='" + title + '\'' +
                ", origin='" + origin + '\'' +
                ", date=" + date +
                ", index=" + indexValue +
                '}';
    }

}



