package com.sun.webmagic.dao;

import com.sun.webmagic.entity.DaoMuBiJiSpiderNoList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @ClassName: SpiderDao
 * @Author: sunji
 * @CreateTime: 2020/12/3 13:48
 */
@Repository
public interface SpiderDao extends JpaRepository<DaoMuBiJiSpiderNoList, Integer> {
}
