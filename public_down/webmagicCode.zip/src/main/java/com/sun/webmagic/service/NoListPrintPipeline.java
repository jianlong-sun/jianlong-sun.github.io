package com.sun.webmagic.service;

import com.sun.webmagic.entity.DaoMuBiJiSpiderNoList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.PageModelPipeline;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @ClassName: SpiderServiceImpl
 * @Author: sunji
 * @CreateTime: 2020/12/3 13:46
 */
@Component
public class NoListPrintPipeline implements PageModelPipeline<DaoMuBiJiSpiderNoList> {

    @Autowired
    private SpiderService spiderService;

    private static Pattern NUMBER_PATTERN = Pattern.compile("\\d+-\\d+-\\d+");
    @Override
    public void process(DaoMuBiJiSpiderNoList daoMuBiJiSpiderNoList, Task task) {

        System.out.println(daoMuBiJiSpiderNoList);
        String date = daoMuBiJiSpiderNoList.getDate();
        Matcher matcher = NUMBER_PATTERN.matcher(date);
        if(matcher.find()){
            daoMuBiJiSpiderNoList.setDate(matcher.group());
        }
        spiderService.save(daoMuBiJiSpiderNoList);
    }
}