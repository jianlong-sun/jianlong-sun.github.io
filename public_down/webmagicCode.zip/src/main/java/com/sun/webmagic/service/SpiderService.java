package com.sun.webmagic.service;

import com.sun.webmagic.dao.SpiderDao;
import com.sun.webmagic.entity.DaoMuBiJiSpiderNoList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.model.OOSpider;

/**
 * @ClassName: spiderService
 * @Author: sunji
 * @CreateTime: 2020/12/3 13:56
 */
@Service
public class SpiderService {
    @Autowired
    private SpiderDao spiderDao;
    @Autowired
    private  NoListPrintPipeline noListPrintPipeline;

    public void save(DaoMuBiJiSpiderNoList daoMuBiJiSpiderNoList) {
        spiderDao.save(daoMuBiJiSpiderNoList);
    }
    public void run(){
        Spider thread = OOSpider.create(Site.me().setSleepTime(1000)
                , noListPrintPipeline, DaoMuBiJiSpiderNoList.class)
                .addUrl("http://seputu.com").thread(5);
        thread.run();
    }
}
